<?php

return [
    'adminEmail' => 'admin@example.com',
    'user.passwordResetTokenExpire' => 3600,
    'supportEmail' => 'robot@devreadwrite.com'
];
