<a class="dialogbox" id="call_order_link" rel="680x340" href="/templates/forms/call_order.php">Заказать звонок</a>

<div>
    Заказ торта с новым дизайном, отправить заявку по WhatsApp 24/7<br>
    <span>+7 903 755 1328 Андрей</span><br>
    Заказ торта с готовым дизайном<br>
    ежедневно 10-19<br>
<span>+7 916 697 15 14 Анастасия</span>
</div>