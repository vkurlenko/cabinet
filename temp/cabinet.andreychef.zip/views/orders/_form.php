<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Orders */
/* @var $form yii\widgets\ActiveForm */
//debug(\app\controllers\OrdersController::getClients());
use kartik\date\DatePicker;

$datepicker = [
    'name' => 'Выберите дату',
    'value' => date('d-M-Y', strtotime('+2 days')),
    'options' => ['placeholder' => 'Выберите дату ...'],
    'pluginOptions' => [
        'format' => 'yyyy-mm-dd',
        'todayHighlight' => true
    ]
];
?>

<div class="orders-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'uid')->dropDownList(\app\controllers\OrdersController::getPersons('user')) ?>

    <?= $form->field($model, 'name')->dropDownList(\app\controllers\OrdersController::getProducts()) ?>

    <?= $form->field($model, 'filling')->dropDownList(\app\controllers\OrdersController::getFills()) ?>

    <?= $form->field($model, 'description')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'deliv_date')->widget(\kartik\date\DatePicker::className(), $datepicker); ?>

    <?= $form->field($model, 'address')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'cost')->textInput() ?>

    <?= $form->field($model, 'payed')->textInput() ?>

    <?/*= $form->field($model, 'order_date')->textInput() */?>

    <?/*= $form->field($model, 'update_date')->textInput() */?>

    <?= $form->field($model, 'manager')->dropDownList(\app\controllers\OrdersController::getPersons('manager')) ?>

    <?= $form->field($model, 'status')->dropDownList(\app\models\Orders::getStatus()) ?>

    <div class="form-group">
        <?= Html::submitButton('Сохранить', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
