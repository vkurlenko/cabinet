<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Orders */

$this->title = $model->name;
$this->params['breadcrumbs'][] = ['label' => 'Заказы', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="orders-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Редактировать', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Удалить', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Вы действительно хотите удалить заказ?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            [
                'attribute' => 'uid',
                'value' => function($data){
                    $users = \app\controllers\OrdersController::getPersons('user');
                    return $users[$data->uid];
                }
            ],
            [
                'attribute' => 'name',
                'value' => function($data){
                    $products = \app\controllers\OrdersController::getProducts();
                    return $products[$data->name];
                }
            ],
            [
                'attribute' => 'filling',
                'value' => function($data){
                    $fills = \app\controllers\OrdersController::getFills();
                    return $fills[$data->filling];
                }
            ],
            'description:ntext',
            'deliv_date',
            'address:ntext',
            'cost',
            'payed',
            'order_date',
            'update_date',
            [
                'attribute' => 'manager',
                'value' => function($data){
                    $users = \app\controllers\OrdersController::getPersons('manager');
                    return $users[$data->manager];
                }
            ],
            [
                'attribute' => 'status',
                'value' => function($data, $model){
                    $arr = \app\models\Orders::getStatus();
                    return $arr[$data->status];
                }
            ],
        ],
    ]) ?>

</div>