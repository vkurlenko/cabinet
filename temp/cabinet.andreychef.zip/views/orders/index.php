<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\OrdersSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Список заказов';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="orders-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Создать новый заказ', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>
    <? //debug(\app\controllers\OrdersController::getProducts());?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        //'filterModel' => $searchModel,
        'columns' => [
            //['class' => 'yii\grid\SerialColumn'],

            [
                'attribute' => 'id',
                'label' => '№',
                'value' => function($data){
                    return $data->id;
                }
            ],
			'order_date',
            [
                'attribute' => 'name',
                'value' => function($data){
                    $products = \app\controllers\OrdersController::getProducts();
                    return $products[$data->name];
                }
            ],
			'cost',
            [
                'attribute' => 'status',
                'value' => function($data){
                    $stats = \app\models\Orders::getStatus();
                    return $stats[$data->status];
                }
            ],
            [
                'attribute' => 'uid',
                'value' => function($data){
					$users = \app\controllers\OrdersController::getPersons('user');
                    return $users[$data->uid];
                }
            ],
            [
                'attribute' => 'manager',
                'value' => function($data){
                    $users = \app\controllers\OrdersController::getPersons('manager');
                    return $users[$data->manager];
                }
            ],
            
            //'filling:ntext',
            //'description:ntext',
            //'deliv_date',
            //'address:ntext',
            //'cost',
            //'payed',
            //'order_date',
            //'update_date',
            //'manager',
            //'status',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>


</div>
